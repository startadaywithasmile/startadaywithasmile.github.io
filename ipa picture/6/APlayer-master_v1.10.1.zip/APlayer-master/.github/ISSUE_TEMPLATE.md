中文用户请注意：请尽量用**英文**描述你的 issue，这样能够让尽可能多的人帮到你。

If you want to report a bug, please provide the following information:

-   The steps to reproduce.
-   A minimal demo of the problem via https://jsfiddle.net or http://codepen.io/pen if possible.
-   Which versions of APlayer, and which browser / OS are affected by this issue?
